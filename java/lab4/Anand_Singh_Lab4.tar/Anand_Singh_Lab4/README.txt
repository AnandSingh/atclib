Lab 4 Assignment

**********************************************************************************************
- Lab 10 (page 251)
Files: Lab_10_Hypothesize
       ArrayListRemoveInsert.java
       ArrayListRemoveInsert.class

Details:
Lab_10_Hypothesize         : contains Hypothesize for Lab 10
ArrayListRemoveInsert.java : conatins the souce code for insert and remove method for conclude

1. How to compile program
==============================================
# enter below command to compile
$ javac ArrayListRemoveInsert.java

2. How to run program
==============================================
# enter below command to run the program

$ java ArrayListRemoveInsert

**************************************************************************************************

- Chapter 6, Programming Exercises: 6.4 (page 260), 6.12, 6.13 (pages 262-263)
Files: Lab4_64Clone.java
       Lab4_64Clone.class
       Lab4_612.java
       Lab4_612.class
       Lab4_613.java
       Lab4_613.class

Details:
Lab4_64Clone.java : contains source code for Programming Exercice 6.4
Lab4_612.java     : contains source code for Programming Exercice 6.12, this programs takes inputs from user (menu)
Lab4_613.java     : contains source code for Programming Exercice 6.13, this programs takes input from user (menu)

1. How to compile program
==============================================
# enter below command to compile
$ javac Lab4_64Clone.java
$ javac Lab4_612.java
$ javac Lab4_613.java

2. How to run program
==============================================
# enter below command to run the program

$ java Lab4_64Clone
$ java Lab4_612
$ java Lab4_613




