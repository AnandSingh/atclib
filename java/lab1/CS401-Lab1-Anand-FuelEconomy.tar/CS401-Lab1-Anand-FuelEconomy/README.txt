FuleEconomy progarm is for calculating the Fule Economy in 
Kilometer per liter. This program runs in an interactive fashion 
and soley depends on user input.

1. How to compile program
==============================================
# enter below command to compile
$ javac FuleEconomy.java

2. How to run program
==============================================
# enter below command to run the program

$ java FuleEconomy

# The Program will display the menu as below
====== MENU for calculating Fule Economy =======
 1. To calculate Fule Economy.
 2. Exit.
 Enter your choice : 

# eneter '1' to calculte Fule Economy or 2 to exit from program
# If user press 1 the program will prompt user to eneter 
# Distance Traveled and fule consumed one by one and 
# display the Fule Economy in terms of Km/L
# below is the console example for same

Enter the KiloMeter Traveled : 78256.50
Enter Liters of Fules consumed : 256.23
Average Km/L is : 305.4150567849198 Km/L
 



